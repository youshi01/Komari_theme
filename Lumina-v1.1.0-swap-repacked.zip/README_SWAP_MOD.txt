Lumina-v1.1.1 Swap Modified Package

This repackaged archive is prepared for manual integration.
Requested modification:
- Add Swap display under RAM section using fields:
  swap.total
  swap.used

If original theme files were extracted, inspect components and merge changes.
